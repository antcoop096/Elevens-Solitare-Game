public class Deck{ //deck class

  private Card[] cards; //deck of cards
  private int size; //amount of cards left in deck

 //a method to test equality between two card objects.

  public Deck(String[] ranks, String[] suits, int[] values){ //deck constructor
   this.size = (ranks.length * suits.length);
   cards = new Card[this.size];
   int index = 0;
   for (int r = 0; r < ranks.length; r++){
    for (int s = 0; s < suits.length; s++){ 
     Card newCard = new Card(ranks[r], suits[s], values[r]);
     this.cards[index] = newCard;
     index++;
  

    }
   }
   shuffle();
    
  }
 //checks if the deck is empty, this gives the win condition
 public boolean isEmpty(){
  if (this.size == 0){ 
   return true;
  
  }
  else{
   return false;
    
  }
 }
 //Deck size 
 public int size(){ 
  return this.size;
   
 }
 //Deals the cards to the player once a match is made 
 public Card deal(){
  this.size -= 1;
  if (this.size >= 0){
   return cards[this.size];
  }
  else{
   return null;
    
  }
    
  }
   
 //Tells the player how many cards remain in the deck 
 public String toString(){
  String string = "size: " + this.size + "\n" + "Undealt cards: \n";
  for (int i = 0; i < this.size; i++){
   string += this.cards[i].toString() + "\n";
  }
  string += "\n" + "Dealt cards: " + "\n";
  for (int i = this.size; i < this.cards.length; i++){
   string += this.cards[i].toString() + "\n";
  }
   
  return string;
    
  }
//shuffles a deck when a new rounds begins
 public void shuffle(){
  this.size = cards.length;
  for (int k = 51; k >= 1; k--){
   int r = (int)(Math.random() * (k + 1));
   Card temp = this.cards[r];
   this.cards[r] = this.cards[k];
   this.cards[k] = temp;
    
  }
 }
    
   

    
  
   
  


   
   
  

   
 }
 
 


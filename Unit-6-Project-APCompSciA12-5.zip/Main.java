//Name: Anthony Cooper & Jonathan Horgan
//Date: 02/07/23
//Title: Elevens Solitare Game
//Descrpition: This program simulates a game of the card game Elevens.


import javax.swing.JFrame;  //imports
import javax.swing.JLabel; 
import javax.swing.SwingConstants;
public class Main{ //main class

public static void main(String[] args){ //main method
  CardGameGUI gui = new CardGameGUI(new ElevensBoard()); //bring in gui
  gui.displayGame();

  final String[] rank = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"}; //list of ranks suits and values
  final String[] suit = {"Spades", "Hearts", "Diamonds", "Clubs"};
  final int[] pointValues = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0, 0, 0};
  Card c1 = new Card("K", "Spades", 5); //for testing
  Card c2 = new Card("K", "Spades", 5); 
  Deck d1 = new Deck(rank, suit, pointValues);
  System.out.println(d1.size());
  for(int i = 0; i < 50; i++){
   d1.deal();
    
  }
  System.out.println(d1);

       




      
    }
}
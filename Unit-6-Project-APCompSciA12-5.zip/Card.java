public class Card //card class
{

 private String rank = "";  //instance variables of rank suit and value
 private String suit = "";
 private int pointValue = 0;
  
 public Card(String cardRank, String cardSuit, int cardPointValue){ //constructs a card
  rank = cardRank;
  suit = cardSuit;
  pointValue = cardPointValue;

   
 }
// Getters for card variables
 public String getRank(){
  return rank;
   
 }

 public String getSuit(){
  return suit;
   
 }
 
  public int getPointValue(){
  return pointValue;
   
 }
//Checks card compatability


public boolean equals(Card c){
  return this.getPointValue() == c.getPointValue() && this.getRank().equals(c.getRank()) && this.getSuit().equals(c.getSuit());
 }
  


  //Gives player the card rank, value and suit
  public String toString(){
  return this.getRank() + " of " + this.getSuit() + " (point value = " + String.valueOf(this.getPointValue()) + ")";
   
 }
  
 
     //The ranks of the cards for this game to be sent to the deck.
    private static final String[] Rank = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};

    /**
     * The suits of the cards for this game to be sent to the deck.
     */
    private static final String[] Suit = {"Spades", "Hearts", "Diamonds", "Clubs"};

    //The values of the cards for this game to be sent to the deck.
     
    private static final int[] PointValue = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0, 0, 0};
 //a method to test equality between two card objects.

   

  
}  